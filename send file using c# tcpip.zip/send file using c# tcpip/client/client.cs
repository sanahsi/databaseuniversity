﻿using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;

class TCPClient
{
    static void Main(string[] args)
    {
        try
        {
            Int32 port = 12345;
            TcpClient client = new TcpClient("127.0.0.1", port);

            String fileName = "path_to_your_file"; // Replace with the path to your file
            byte[] fileData = File.ReadAllBytes(fileName);

            NetworkStream stream = client.GetStream();

            stream.Write(fileData, 0, fileData.Length);

            byte[] response = new byte[256];
            int bytesRead = stream.Read(response, 0, response.Length);
            Console.WriteLine(Encoding.ASCII.GetString(response, 0, bytesRead));

            client.Close();
        }
        catch (ArgumentNullException e)
        {
            Console.WriteLine("ArgumentNullException: {0}", e);
        }
        catch (SocketException e)
        {
            Console.WriteLine("SocketException: {0}", e);
        }

        Console.WriteLine("\nHit enter to continue...");
        Console.Read();
    }
}